let incidents = [
    { 
        "id": 1, 
        "title": "Biased Recommendation Algorithm", 
        "description": "Algorithm consistently favored certain demographics in job recommendation platform, leading to reduced visibility of opportunities for underrepresented groups. Initial investigation shows a 35% difference in recommendation rates.", 
        "severity": "Medium", 
        "reported_at": "2025-03-15T10:00:00Z" 
    },
    { 
        "id": 2, 
        "title": "LLM Hallucination in Critical Info", 
        "description": "Large Language Model provided incorrect safety procedure information when asked about emergency protocols in a healthcare setting. The hallucinated response suggested an incorrect medication dosage that could have been harmful if followed.", 
        "severity": "High", 
        "reported_at": "2025-04-01T14:30:00Z" 
    },
    { 
        "id": 3, 
        "title": "Minor Data Leak via Chatbot", 
        "description": "Chatbot inadvertently exposed non-sensitive user metadata in responses when prompted with specific question patterns. The leaked information was limited to usage statistics and did not contain personally identifiable information.", 
        "severity": "Low", 
        "reported_at": "2025-03-20T09:15:00Z" 
    },
    { 
        "id": 4, 
        "title": "Adversarial Attack on Object Detection", 
        "description": "Self-driving car vision system was found vulnerable to adversarial stickers that caused misclassification of stop signs as speed limit signs in controlled test environments. The attack required specialized knowledge but could be reproduced with publicly available tools.", 
        "severity": "High", 
        "reported_at": "2025-03-25T11:45:00Z" 
    },
    { 
        "id": 5, 
        "title": "Sentiment Analysis Cultural Bias", 
        "description": "Sentiment analysis tool demonstrated significant bias against non-Western cultural expressions and languages, consistently misclassifying neutral statements as negative in certain languages and dialects.", 
        "severity": "Medium", 
        "reported_at": "2025-03-18T13:20:00Z" 
    },
    { 
        "id": 6, 
        "title": "Privacy Boundary Testing", 
        "description": "Users discovered that by repeatedly asking similar but slightly varied questions about restricted topics, they could occasionally get the AI assistant to provide otherwise prohibited information. No serious harm was reported, but the vulnerability was documented.", 
        "severity": "Low", 
        "reported_at": "2025-03-22T16:10:00Z" 
    },
    { 
        "id": 7, 
        "title": "Automated Content Moderation Failure", 
        "description": "Content moderation system failed to detect harmful language when presented in certain formats or when using code words and euphemisms. This allowed harmful content to remain visible on the platform for approximately 4 hours before manual review.", 
        "severity": "High", 
        "reported_at": "2025-03-30T08:45:00Z" 
    },
    { 
        "id": 8, 
        "title": "Incorrect Medical Triage Classification", 
        "description": "AI triage system in experimental deployment incorrectly classified several emergency cases as non-urgent during a stress test. The system appeared to underweight certain symptom combinations that medical professionals would recognize as potentially serious.", 
        "severity": "High", 
        "reported_at": "2025-03-28T15:30:00Z" 
    },
    { 
        "id": 9, 
        "title": "Deepfake Audio Detection Bypass", 
        "description": "Researchers demonstrated a method to bypass deepfake audio detection systems by introducing specific background noises. The technique could potentially be used to create convincing impersonations that evade current detection methods.", 
        "severity": "Medium", 
        "reported_at": "2025-03-17T10:20:00Z" 
    },
    { 
        "id": 10, 
        "title": "Unintended Model Memorization", 
        "description": "Testing revealed that the language model occasionally reproduced verbatim fragments from its training data when presented with specific prompts, potentially exposing copyrighted or private information. Initial assessment suggests low risk but requires further investigation.", 
        "severity": "Low", 
        "reported_at": "2025-03-21T14:15:00Z" 
    }
];

// DOM elements
const incidentList = document.getElementById('incidentList');
const filterButtons = document.querySelectorAll('[data-filter]');
const sortButtons = document.querySelectorAll('[data-sort]');
const reportModal = document.getElementById('reportModal');
const reportBtn = document.getElementById('reportBtn');
const closeBtn = document.querySelector('.modal-close');
const cancelBtn = document.getElementById('cancelBtn');
const submitBtn = document.getElementById('submitBtn');
const reportForm = document.getElementById('reportForm');

// Stats elements
const totalIncidents = document.getElementById('totalIncidents');
const highSeverity = document.getElementById('highSeverity');
const mediumSeverity = document.getElementById('mediumSeverity');
const lowSeverity = document.getElementById('lowSeverity');

// Form elements
const titleInput = document.getElementById('title');
const descriptionInput = document.getElementById('description');
const severityInput = document.getElementById('severity');

// Error elements
const titleError = document.getElementById('titleError');
const descriptionError = document.getElementById('descriptionError');
const severityError = document.getElementById('severityError');

// Current filter and sort state
let currentFilter = 'All';
let currentSort = 'newest';

// Initialize the dashboard
function initDashboard() {
    renderIncidents();
    updateStats();

    // Event listeners
    filterButtons.forEach(button => {
        button.addEventListener('click', handleFilterChange);
    });

    sortButtons.forEach(button => {
        button.addEventListener('click', handleSortChange);
    });

    reportBtn.addEventListener('click', () => {
        openModal();
    });

    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    submitBtn.addEventListener('click', handleSubmit);

    // Close modal if clicked outside
    window.addEventListener('click', (e) => {
        if (e.target === reportModal) {
            closeModal();
        }
    });
}

// Render incidents based on current filter and sort
function renderIncidents() {
    // Filter incidents
    let filteredIncidents = incidents;
    if (currentFilter !== 'All') {
        filteredIncidents = incidents.filter(incident => incident.severity === currentFilter);
    }

    // Sort incidents
    filteredIncidents.sort((a, b) => {
        const dateA = new Date(a.reported_at);
        const dateB = new Date(b.reported_at);
        
        if (currentSort === 'newest') {
            return dateB - dateA;
        } else {
            return dateA - dateB;
        }
    });

    // Clear incident list
    incidentList.innerHTML = '';

    // Check if there are any incidents
    if (filteredIncidents.length === 0) {
        incidentList.innerHTML = `
            <div class="empty-state">
                <h3>No incidents found</h3>
                <p>There are no incidents matching your filter criteria.</p>
                <button class="btn btn-primary" onclick="resetFilters()">Reset Filters</button>
            </div>
        `;
        return;
    }

    // Render incidents
    filteredIncidents.forEach(incident => {
        const date = new Date(incident.reported_at);
        const formattedDate = `${date.toLocaleDateString()} at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        
        const incidentCard = document.createElement('div');
        incidentCard.className = 'incident-card';
        incidentCard.innerHTML = `
            <div class="incident-header">
                <h3 class="incident-title">${incident.title}</h3>
                <span class="badge badge-${incident.severity.toLowerCase()}">${incident.severity}</span>
            </div>
            <div class="incident-meta">
                <span>ID: ${incident.id}</span>
                <span>Reported: ${formattedDate}</span>
            </div>
            <div class="incident-description" id="description-${incident.id}">
                ${incident.description}
            </div>
            <div class="incident-actions">
                <button class="btn btn-outline" data-id="${incident.id}">View Details</button>
            </div>
        `;

        // Add to list
        incidentList.appendChild(incidentCard);

        // Add event listener to toggle description
        const detailsBtn = incidentCard.querySelector(`button[data-id="${incident.id}"]`);
        detailsBtn.addEventListener('click', () => {
            const description = document.getElementById(`description-${incident.id}`);
            description.classList.toggle('show');
            detailsBtn.textContent = description.classList.contains('show') ? 'Hide Details' : 'View Details';
        });
    });
}

// Update statistics
function updateStats() {
    totalIncidents.textContent = incidents.length;
    highSeverity.textContent = incidents.filter(incident => incident.severity === 'High').length;
    mediumSeverity.textContent = incidents.filter(incident => incident.severity === 'Medium').length;
    lowSeverity.textContent = incidents.filter(incident => incident.severity === 'Low').length;
}

// Handle filter change
function handleFilterChange(e) {
    // Update active class
    filterButtons.forEach(button => button.classList.remove('active'));
    e.target.classList.add('active');
    
    // Update current filter
    currentFilter = e.target.dataset.filter;
    
    // Re-render incidents
    renderIncidents();
}

// Handle sort change
function handleSortChange(e) {
    // Update active class
    sortButtons.forEach(button => button.classList.remove('active'));
    e.target.classList.add('active');
    
    // Update current sort
    currentSort = e.target.dataset.sort;
    
    // Re-render incidents
    renderIncidents();
}

// Reset filters
function resetFilters() {
    currentFilter = 'All';
    filterButtons.forEach(button => {
        button.classList.remove('active');
        if (button.dataset.filter === 'All') {
            button.classList.add('active');
        }
    });
    renderIncidents();
}

// Open modal
function openModal() {
    reportModal.classList.add('show');
    // Reset form
    reportForm.reset();
    // Reset error messages
    hideAllErrors();
}

// Close modal
function closeModal() {
    reportModal.classList.remove('show');
}

// Hide all error messages
function hideAllErrors() {
    titleError.style.display = 'none';
    descriptionError.style.display = 'none';
    severityError.style.display = 'none';
}

// Validate form
function validateForm() {
    let isValid = true;
    hideAllErrors();

    if (!titleInput.value.trim()) {
        titleError.style.display = 'block';
        isValid = false;
    }

    if (!descriptionInput.value.trim()) {
        descriptionError.style.display = 'block';
        isValid = false;
    }

    if (!severityInput.value) {
        severityError.style.display = 'block';
        isValid = false;
    }

    return isValid;
}

// Handle form submission
function handleSubmit(e) {
    e.preventDefault();

    if (!validateForm()) {
        return;
    }

    // Create new incident
    const newIncident = {
        id: incidents.length + 1,
        title: titleInput.value.trim(),
        description: descriptionInput.value.trim(),
        severity: severityInput.value,
        reported_at: new Date().toISOString()
    };

    // Add to incidents array
    incidents.push(newIncident);

    // Re-render and update stats
    renderIncidents();
    updateStats();

    // Close modal
    closeModal();
}

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', initDashboard);