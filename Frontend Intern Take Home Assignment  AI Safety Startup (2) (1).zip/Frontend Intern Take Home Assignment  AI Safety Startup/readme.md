# AI Safety Incident Dashboard

This project is a web-based dashboard for tracking and managing AI safety incidents. It allows users to view, filter, sort, and report incidents based on severity and date.

## Features

- **View Incidents**: Displays a list of AI safety incidents with details such as title, description, severity, and reported date.
- **Filter by Severity**: Filter incidents by severity levels (Low, Medium, High).
- **Sort by Date**: Sort incidents by newest or oldest first.
- **Report New Incidents**: Add new incidents through a modal form.
- **Statistics**: Displays total incidents and counts by severity.

## Project Structure

```
.
├── data.js                # Placeholder for external data (currently unused)
├── index.html             # Main HTML file
├── index.js               # JavaScript logic for the dashboard
├── styles.css             # Styling for the dashboard
├── Frontend Intern Take Home Assignment  AI Safety Startup.pdf # Assignment details
```

## How to Run

1. Clone or download the repository to your local machine.
2. Open the project folder in Visual Studio Code or any code editor.
3. Use a local server to serve the files (e.g., Live Server extension in VS Code).
4. Open `index.html` in your browser.

## Usage

1. **View Incidents**: The dashboard displays a list of incidents by default.
2. **Filter and Sort**: Use the filter and sort controls to customize the incident list.
3. **Report New Incident**:
   - Click the "Report New Incident" button.
   - Fill in the form with the incident details.
   - Submit the form to add the incident to the list.

## Technologies Used

- **HTML**: Structure of the dashboard.
- **CSS**: Styling and layout.
- **JavaScript**: Logic for filtering, sorting, and managing incidents.

## Screenshots

![Dashboard Screenshot](./dashboard-screenshot.png)
![Dashboard Screenshot](./dashboard-screenshot-2.png)

## License

This project is for educational purposes and is not licensed for commercial use.